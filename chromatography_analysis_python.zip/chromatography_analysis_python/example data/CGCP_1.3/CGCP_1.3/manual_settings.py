"""
This script holds the information needed in 'CGCP' in order to treat data.
"""

"""
MANUEL SETTINGS SECTION
"""
#Path to files. The path here, can be both relative and absolute
path = r"C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\GC product analysis\single runs"
# path = r"C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\Calibration\new GC calibration\data\ANNA_STANDARDS_NEWFLOW 2019-02-15 11-38-32 - Copy"

# path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\GC product analysis\ANNA_POR_NEW_FLOWRATE 2019-05-23 16-56-13'
# path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\GC product analysis\ANNA_POR_NEW_FLOWRATE 2019-05-24 18-35-58'
# path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\GC product analysis\ANNA_POR_NEW_FLOWRATE 2019-05-27 17-56-38'

# path = r"C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\Calibration\new GC calibration\20190520 new calibration\GC_RAMP_PROPENE-method\1%CO in Ar" #\1%CO in Ar or 1%H2 in Ar

# path = r"C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\Calibration\new GC calibration\20190520 new calibration\GC_RAMP_SHORT_CO2-method\HER in Ar" # \COO in 1%CO in Ar or HER in Ar
#
# output_path = r"C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\GC product analysis\Data analysis"
#
# output_path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\GC product analysis\single runs\data_analysis_test'


output_path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\IPA oxidation\GC' #IPA analysis

# output_path = r"C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\Calibration\new GC calibration\20190520 new calibration\analysis\HER for volume" #CO and H2 in Ar, CO2 from CO, HER for volume
save_plots = True

#settings for calculation of concentration and electrochemical characteristics
# calibration_path = r"C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\Calibration\new GC calibration\20190215_calibration\calibration_lines_HSGC150219.csv"
calibration_path = r"C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\Calibration\new GC calibration\calibration_lines_HSGC150219+GC200519+HPLC15062019.csv"
echem = True #calculate FE and partial current density
exp_length = 30 #CA duration in min
echem_info = {"standard": {'liquid_volume': 12, 'total_charge': 0.1, 'electrode_area': 2},
             "AW Au 005": {'liquid_volume': 12.85, 'total_charge': 0.033512166, 'electrode_area': 14.7}, #should be 006, but for gas products name in file is wrong
              "AW Au 007": {'liquid_volume': 12.65, 'total_charge': 0.114965769099999, 'electrode_area': 13.6},
              "AW Au 008": {'liquid_volume': 12.45, 'total_charge': 0.3871161945, 'electrode_area': 15.5},
              "AW Au 010": {'liquid_volume': 12.95, 'total_charge': 0.001000813, 'electrode_area': 8.1},
              "AW Au 011": {'liquid_volume': 12.7, 'total_charge': 0.04860607073, 'electrode_area': 9.8},
              "AW Au 012": {'liquid_volume': 12.6, 'total_charge': 0.337988198972, 'electrode_area': 8.4},
              "AW AuPd 9010 004": {'liquid_volume': 12.35, 'total_charge': 0.5205460207, 'electrode_area': 13.8},
              "AW AuPd 9010 005": {'liquid_volume': 12.77, 'total_charge': 0.004187647997, 'electrode_area': 14.6},
              "AW AuPd 9010 006": {'liquid_volume': 12.7, 'total_charge': 0.5023260762534, 'electrode_area': 13.4},
              "AW AuPd 9010 007": {'liquid_volume': 12.7, 'total_charge': 0.0430297937, 'electrode_area': 14.7},
              "AW AuPd 9010 010": {'liquid_volume': 12.75, 'total_charge': 0.5205460207, 'electrode_area': 12.9},
              "AW AuPd 9010 011": {'liquid_volume': 12.8, 'total_charge': 0.5205460207, 'electrode_area': 13.5},
              "AW AuPd 9010 012": {'liquid_volume': 12.75, 'total_charge': 0.5205460207, 'electrode_area': 12.15},

              "AW AuPd 1090 003": {'liquid_volume': 12.5, 'total_charge': 0.4226389751, 'electrode_area': 48.6},
              "AW AuPd 1090 004": {'liquid_volume': 12.9, 'total_charge': 0.06137843503, 'electrode_area': 33.0},
              "AW AuPd 1090 005": {'liquid_volume': 12.65, 'total_charge': 0.0438387044, 'electrode_area': 77.8},
              "AW AuPd 1090 006": {'liquid_volume': 12.55, 'total_charge': 0.226526717, 'electrode_area': 34.0},

              "AW AuPd 1090 008": {'liquid_volume': 12.65, 'total_charge': 0.025547447, 'electrode_area': 34.1},
              "AW AuPd 1090 010": {'liquid_volume': 12.35, 'total_charge': 0.4156330985, 'electrode_area': 42.8},
              "AW AuPd 1090 011": {'liquid_volume': 12.6, 'total_charge': 0.26448773, 'electrode_area': 39.2},
              "AW Pd 001": {'liquid_volume': 12.6, 'total_charge': 0.0251471572, 'electrode_area': 62.6},
              "AW Pd 003": {'liquid_volume': 12.65, 'total_charge': 0.374614017, 'electrode_area': 71.9},
              "AW Pd 004": {'liquid_volume': 12.75, 'total_charge': 0.205926865, 'electrode_area': 66.8},

              #IPA samples:
              "AW Au 014": {'liquid_volume': 11.6 , 'total_charge': 0.0032998, 'electrode_area': 8.4},
              "AW Au 015": {'liquid_volume': 11.8, 'total_charge': 0.0056387, 'electrode_area': 8.02},
              "AW Aurich 013": {'liquid_volume': 11.2, 'total_charge': 0.01306, 'electrode_area': 12.88},
              "AW Aurich 014": {'liquid_volume': 11.8, 'total_charge': 0.0125628, 'electrode_area': 12.63},
              "AW Pd ec 005": {'liquid_volume': 11.7, 'total_charge': 0.0378881, 'electrode_area': 110.88},
              "AW Pd ec 006": {'liquid_volume': 11.6, 'total_charge': 0.0067269, 'electrode_area': 38.28},
              "AW Pdrich 013": {'liquid_volume': 11.6, 'total_charge': 0.0168218 , 'electrode_area': 53.33},
              "AW Pdrich 014": {'liquid_volume': 11.6, 'total_charge': 0.0232841, 'electrode_area': 38.04},



              }#total electrolyte volume in mL, total charge at the end of the CA experiment in C, electrode area cm2
electrons = {} #dict to be filled below for electron transferred for each compound.


#keys for detectors, which will depend on the actual GC
data_type = "GC" #so far this is only used to find out whether it's HPLC data or not

FID_key = 'FID1A.ch'
# TCD_key = None
TCD_key = 'TCD2B.ch'

detector_keys = [FID_key, TCD_key]

#deactivated in script
# #injections to be skipped at the beginning
# skip_start = 0 #set to 1, and it will skip the first injection. The injection-times are unaltered
#
# #injections to be skipped at the end
# skip_end = 0 #set to 1, and it will skip the last injectionplt.show

#A lot of plot-settings
import matplotlib as mpl

#Titles written in figures
plots_title = ''

#plot-design
font = {'family' : 'serif',#'Palatino Linotype',
        #'weight' : 'bold',
        'size'   : 18}
mpl.rc('font', **font)

#Figure size
from pylab import rcParams
rcParams['figure.figsize'] = 10, 7
            
"""
INFO FOR BACKGROUND FITTING AND INTEGRATION

Names ('keys') and ordering of the peaks within the fit_info is abitrary, since fit_info is a dictionary.
The disignation 'P1', 'P2' and so on are not used for anything. The gc_parser code will just iterate over
all entries in the dictionary anyway.

New peaks can be added by simply 'copy-paste' a section, containing a peak. It is important to have different
entries (P1,P2 etc.), else earlier entries with same name will be overwritten when integrating spectra.

Peaks that need to be excluded, can be out-commented by # or sectional wise, like 'P2' in TCD.

Compound-names are written in a latex-syntax.

Colors are used in the plots
"""
#for the test_data
fit_info = {}
fit_info['settings'] = {}
fit_info['settings'][FID_key] = {}
fit_info['settings'][FID_key]['background_range'] = [0.05] #minutes
# fit_info['settings'][TCD_key] = {}
# fit_info['settings'][TCD_key]['background_range'] = [0.05] #minutes

fit_info[FID_key] = {}

#gas products:
#FID: CO, methane, CO2, ethylene
#TCD: H2 (4.2), air (N2+O2) (5.x)



fit_info[FID_key]['CO'] = {}
fit_info[FID_key]['CO']['start'] = [1.25]
fit_info[FID_key]['CO']['end'] =  [1.35]#[4]
fit_info[FID_key]['CO']['name'] = 'CO'
fit_info[FID_key]['CO']['color'] = 'grey'
fit_info[FID_key]['CO']['mother_peak'] = []
electrons['CO'] = 4

#
fit_info[FID_key]['CH4'] = {}
fit_info[FID_key]['CH4']['start'] = [1.35]
fit_info[FID_key]['CH4']['end'] =  [1.5]#[4]
fit_info[FID_key]['CH4']['name'] = 'CH4'
fit_info[FID_key]['CH4']['color'] = 'r'
fit_info[FID_key]['CH4']['mother_peak'] = ['CO']
electrons['CH4'] = 0 #not a product?!

#
fit_info[FID_key]['CO2'] = {}
fit_info[FID_key]['CO2']['start'] = [1.72]
fit_info[FID_key]['CO2']['end'] =  [2.1]#[4] #2.15 is A BIT TOO FAR FOR for propene oxidation results
fit_info[FID_key]['CO2']['name'] = 'CO2'
fit_info[FID_key]['CO2']['color'] = 'brown'
fit_info[FID_key]['CO2']['mother_peak'] = []
electrons['CO2'] = 6
#
fit_info[FID_key]['CH2CH2'] = {}
fit_info[FID_key]['CH2CH2']['start'] = [2.4]
fit_info[FID_key]['CH2CH2']['end'] =  [2.6]#[4]
fit_info[FID_key]['CH2CH2']['name'] = 'CH2CH2'
fit_info[FID_key]['CH2CH2']['color'] = 'g'
fit_info[FID_key]['CH2CH2']['mother_peak'] = []
electrons['CH2CH2'] = 0 #not a product?!
#



fit_info[TCD_key] = {}

fit_info[TCD_key]['H2'] = {}
fit_info[TCD_key]['H2']['start'] = [4.15]
fit_info[TCD_key]['H2']['end'] =  [4.55]#[4]
fit_info[TCD_key]['H2']['name'] = 'H2'
fit_info[TCD_key]['H2']['color'] = 'b'
fit_info[TCD_key]['H2']['mother_peak'] = []
electrons['H2'] = 2 #not a product?!


fit_info[TCD_key]['air'] = {}
fit_info[TCD_key]['air']['start'] = [5.18]
fit_info[TCD_key]['air']['end'] =  [5.8]#[4]
fit_info[TCD_key]['air']['name'] = 'air'
fit_info[TCD_key]['air']['color'] = 'grey'
fit_info[TCD_key]['air']['mother_peak'] = []
electrons['air'] = 0 #not a product?!


fit_info[TCD_key]['CO_TCD'] = {}
fit_info[TCD_key]['CO_TCD']['start'] = [8.07]
fit_info[TCD_key]['CO_TCD']['end'] =  [8.5]#[4]
fit_info[TCD_key]['CO_TCD']['name'] = 'CO_TCD'
fit_info[TCD_key]['CO_TCD']['color'] = '0.75'
fit_info[TCD_key]['CO_TCD']['mother_peak'] = []
electrons['CO_TCD'] = 0 #not a product?!

# #
#
# fit_info[TCD_key]['CO2'] = {} #P is for peak in spectrum, and are ordered from low to high in retentiontime
# fit_info[TCD_key]['CO2']['start'] = [3.6]
# fit_info[TCD_key]['CO2']['end'] = [4.5]
# fit_info[TCD_key]['CO2']['name'] = 'CO$_2$/3.8 min'
# fit_info[TCD_key]['CO2']['color'] = 'b'
# fit_info[TCD_key]['CO2']['mother_peak'] = []
#