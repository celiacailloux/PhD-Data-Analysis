"""
This script holds the information needed in 'CGCP' in order to treat data.
"""

"""
MANUEL SETTINGS SECTION
"""
#Path to files. The path here, can be both relative and absolute
# path = r"C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\20190614_standards_newlamp_oldmethod50"
# path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\20190614_standards_newlamp_oldmethod50\AcAc+Ac'
# path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\20190614_standards_newlamp_oldmethod50\200_10 files'
# path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\20190614_standards_newlamp_oldmethod50\AlAl+At+PG'


# path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\POR_newlamp_oldmethod_50muL\propene_purged_electrolyte'
# path= r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\IPA oxidation\HPLC'
# path =r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\POR_newlamp_oldmethod_50muL\Au'
# path =r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\POR_newlamp_oldmethod_50muL\Au rich'
# path =r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\POR_newlamp_oldmethod_50muL\Pd rich'
# path =r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\POR_newlamp_oldmethod_50muL\Pd'
# path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\homogeneous Au\HPLC'
# path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\newstuff_october\Pd'
path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\newstuff_october\AuPd4060'

output_path = r'C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\analysis'



save_plots = True

#settings for calculation of concentration and electrochemical characteristics

calibration_path = r"C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\Calibration\new GC calibration\calibration_lines_HSGC150219+GC200519+HPLC15062019_corrected102019.csv"
echem = True #calculate FE and partial current density
exp_length = 30 #CA duration in min
echem_info = {"standard": {'liquid_volume': 12, 'total_charge': 0.1, 'electrode_area': 2},
              "POR_AU_006_REST_injection_1": {'liquid_volume': 12.85, 'total_charge': 0.033512166, 'electrode_area': 14.7},
              "POR_AU_007_REST_injection_1": {'liquid_volume': 12.65, 'total_charge': 0.114965769099999, 'electrode_area': 13.6},
              "POR_AU_008_REST_injection_1": {'liquid_volume': 12.45, 'total_charge': 0.3871161945, 'electrode_area': 15.5},
              "POR_AU_010_REP_injection_1": {'liquid_volume': 12.95, 'total_charge': 0.001000813, 'electrode_area': 8.1},
              "POR_AU_011_REP_injection_1": {'liquid_volume': 12.7, 'total_charge': 0.04860607073, 'electrode_area': 9.8},
              "POR_AU_012_REP_injection_1": {'liquid_volume': 12.6, 'total_charge': 0.337988198972, 'electrode_area': 8.4},
              "POR_AUPD_9010_004_REST_injection_1": {'liquid_volume': 12.35, 'total_charge': 0.5205460207, 'electrode_area': 13.8},
              "POR_AUPD_9010_005_REST_injection_1": {'liquid_volume': 12.77, 'total_charge': 0.004187647997, 'electrode_area': 14.6},
              "POR_AUPD_9010_006_REST_injection_1": {'liquid_volume': 12.7, 'total_charge': 0.5023260762534, 'electrode_area': 13.4},
              "POR_AUPD_9010_007_REST_injection_1": {'liquid_volume': 12.7, 'total_charge': 0.0430297937, 'electrode_area': 14.7},
              "POR_AUPD_9010_010_REP_injection_1": {'liquid_volume': 12.75, 'total_charge': 0.5205460207, 'electrode_area': 12.9},
              "POR_AUPD_9010_011_REP_injection_1": {'liquid_volume': 12.8, 'total_charge': 0.5205460207, 'electrode_area': 13.5},
              "POR_AUPD_9010_012_REP_injection_1": {'liquid_volume': 12.75, 'total_charge': 0.5205460207, 'electrode_area': 12.15},

              "POR_AUPD_1090_003_REST_injection_1": {'liquid_volume': 12.5, 'total_charge': 0.4226389751, 'electrode_area': 48.6},
              "POR_AUPD_1090_004_REST_injection_1": {'liquid_volume': 12.9, 'total_charge': 0.06137843503, 'electrode_area': 33.0},
              "AW AuPd 1090 005": {'liquid_volume': 12.65, 'total_charge': 0.0438387044, 'electrode_area': 77.8},
              "POR_AUPD_1090_006_REST_injection_1": {'liquid_volume': 12.55, 'total_charge': 0.226526717, 'electrode_area': 34.0},
              "POR_AUPD_1090_008_injection_1": {'liquid_volume': 12.65, 'total_charge': 0.025547447, 'electrode_area': 34.1},
              "POR_AUPD_1090_010_injection_1": {'liquid_volume': 12.35, 'total_charge': 0.4156330985, 'electrode_area': 42.8},
              "POR_AUPD_1090_011_injection_1": {'liquid_volume': 12.6, 'total_charge': 0.26448773, 'electrode_area': 39.2},
              "POR_PD_FOAM_EC_001_injection_1": {'liquid_volume': 12.6, 'total_charge': 0.0251471572, 'electrode_area': 62.6},
              "POR_PD_FOAM_EC_003_injection_1": {'liquid_volume': 12.65, 'total_charge': 0.374614017, 'electrode_area': 71.9},
              "POR_PD_FOAM_EC_004_injection_1": {'liquid_volume': 12.75, 'total_charge': 0.205926865, 'electrode_area': 66.8},

              '0POR_AUPD_4060_005_injection_OR_AUPD_4060_005_D_RID': {'liquid_volume': 11.5, 'total_charge': 0.0274301, 'electrode_area': 26.39},
              '0POR_AUPD_4060_006_injection_OR_AUPD_4060_006_D_RID': {'liquid_volume': 11.6, 'total_charge': 0.17896959518, 'electrode_area': 22.66},
              '0POR_AUPD_4060_007_injection_OR_AUPD_4060_007_D_RID': {'liquid_volume': 11.8, 'total_charge': 0.342087226719999, 'electrode_area': 30.71},
              '0POR_AUPD_4060_008_injection_OR_AUPD_4060_008_D_RID': {'liquid_volume': 11.8, 'total_charge': 0.6068523439, 'electrode_area': 31.05},
              '0POR_AUPD_4060_009_injection_OR_AUPD_4060_009_D_RID': {'liquid_volume': 11.7, 'total_charge': 0.02797593934, 'electrode_area': 21.65},
              '0POR_AUPD_4060_010_injection_OR_AUPD_4060_010_D_RID': {'liquid_volume': 11.8, 'total_charge': 0.186801392959999, 'electrode_area': 23.2},
              '0POR_AUPD_4060_011_injection_OR_AUPD_4060_011_D_RID': {'liquid_volume': 11.6, 'total_charge': 0.5971464137, 'electrode_area': 24.12},
              '0POR_AUPD_4060_012_injection_OR_AUPD_4060_012_D_RID': {'liquid_volume': 11.8, 'total_charge': 0.26003669485, 'electrode_area': 34.13},
              '0POR_PD_FOAM_EC_007_injection_OR_PD_FOAM_EC_007_D_RID': {'liquid_volume': 12, 'total_charge': 0.0130424691, 'electrode_area': 44.06},
              '0POR_PD_FOAM_EC_008_injection_OR_PD_FOAM_EC_008_D_RID': {'liquid_volume': 11.7, 'total_charge': 0.11931556 , 'electrode_area': 38.83},
              '0POR_PD_FOAM_EC_009_injection_OR_PD_FOAM_EC_009_D_RID': {'liquid_volume': 11.9, 'total_charge': 0.132974603, 'electrode_area': 66.57},


#IPA samples:
              "AW Au 014": {'liquid_volume': 11.6 , 'total_charge': 0.0032998, 'electrode_area': 8.4},
              "AW Au 015": {'liquid_volume': 11.8, 'total_charge': 0.0056387, 'electrode_area': 8.02},
              "AW Aurich 013": {'liquid_volume': 11.2, 'total_charge': 0.01306, 'electrode_area': 12.88},
              "AW Aurich 014": {'liquid_volume': 11.8, 'total_charge': 0.0125628, 'electrode_area': 12.63},
              "AW Pd ec 005": {'liquid_volume': 11.7, 'total_charge': 0.0378881, 'electrode_area': 110.88},
              "AW Pd ec 006": {'liquid_volume': 11.6, 'total_charge': 0.0067269, 'electrode_area': 38.28},
              "AW Pdrich 013": {'liquid_volume': 11.6, 'total_charge': 0.0168218 , 'electrode_area': 53.33},
              "AW Pdrich 014": {'liquid_volume': 11.6, 'total_charge': 0.0232841, 'electrode_area': 38.04},

#homogeneous cat/reaction Au:


              }#total electrolyte volume in mL, total charge at the end of the CA experiment in C, electrode area cm2
electrons = {} #dict to be filled below for electron transferred for each compound.


#keys for detectors, which will depend on the actual GC
data_type = "HPLC"

det_1_key = '200_10'
det_2_key = '208_4'
det_3_key = '280_10'
det_4_key = 'RID'

detector_keys = [det_1_key]
# detector_keys = [det_1_key, det_2_key, det_4_key]

                 # det_4_key]

#deactivated in script
# #injections to be skipped at the beginning
# skip_start = 0 #set to 1, and it will skip the first injection. The injection-times are unaltered
#
# #injections to be skipped at the end
# skip_end = 0 #set to 1, and it will skip the last injection

#A lot of plot-settings
import matplotlib as mpl

#Titles written in figures
plots_title = ''

#plot-design
font = {'family' : 'serif',#'Palatino Linotype',
        #'weight' : 'bold',
        'size'   : 18}
mpl.rc('font', **font)

#Figure size
from pylab import rcParams
rcParams['figure.figsize'] = 10, 7
            
"""
INFO FOR BACKGROUND FITTING AND INTEGRATION

Names ('keys') and ordering of the peaks within the fit_info is abitrary, since fit_info is a dictionary.
The disignation 'P1', 'P2' and so on are not used for anything. The gc_parser code will just iterate over
all entries in the dictionary anyway.

New peaks can be added by simply 'copy-paste' a section, containing a peak. It is important to have different
entries (P1,P2 etc.), else earlier entries with same name will be overwritten when integrating spectra.

Peaks that need to be excluded, can be out-commented by # or sectional wise, like 'P2' in TCD.

Compound-names are written in a latex-syntax.

Colors are used in the plots
"""

fit_info = {}
fit_info['settings'] = {}
fit_info['settings'][det_1_key] = {}
# fit_info['settings'][det_1_key]['background_range'] = [0.05] #minutes


#det 1 is 200_10, most important for allyl alcohol
fit_info[det_1_key] = {}

fit_info[det_1_key]['CH2CH2CH3'] = {}
fit_info[det_1_key]['CH2CH2CH3']['start'] = [32.5]
fit_info[det_1_key]['CH2CH2CH3']['end'] =  [35]#[4]
fit_info[det_1_key]['CH2CH2CH3']['name'] = 'propene ' + str(det_1_key)
fit_info[det_1_key]['CH2CH2CH3']['color'] = 'grey'
fit_info[det_1_key]['CH2CH2CH3']['mother_peak'] = []
electrons['CH2CH2CH3'] = 0 #not a product?!


#
# fit_info[det_1_key]['AlAl'] = {} #P is for peak in spectrum, and are ordered from low to high in retentiontime
# fit_info[det_1_key]['AlAl']['start'] = [20.07]
# fit_info[det_1_key]['AlAl']['end'] = [21.4] #[21.4]
# fit_info[det_1_key]['AlAl']['name'] = 'Allyl alcohol ' + str(det_1_key)
# fit_info[det_1_key]['AlAl']['color'] = 'orange'
# fit_info[det_1_key]['AlAl']['mother_peak'] = []
# electrons['AlAl'] = 2
#
# fit_info[det_1_key]['At'] = {} #P is for peak in spectrum, and are ordered from low to high in retentiontime
# fit_info[det_1_key]['At']['start'] = [21.4] #[21.4]
# fit_info[det_1_key]['At']['end'] = [21.9] #
# fit_info[det_1_key]['At']['name'] = 'Acetone ' + str(det_1_key)
# fit_info[det_1_key]['At']['color'] = '#008080'
# fit_info[det_1_key]['At']['mother_peak'] = []
# electrons['At'] = 2


# for higher AlAl concentrations
fit_info[det_1_key]['AlAl'] = {} #P is for peak in spectrum, and are ordered from low to high in retentiontime
fit_info[det_1_key]['AlAl']['start'] = [20.07]
fit_info[det_1_key]['AlAl']['end'] = [21.15]#[22.45] #there's actually a second peak here that needs to be subtracted...
fit_info[det_1_key]['AlAl']['name'] = 'Allyl alcohol ' + str(det_1_key)
fit_info[det_1_key]['AlAl']['color'] = 'orange'
fit_info[det_1_key]['AlAl']['mother_peak'] = []
electrons['AlAl'] = 2
fit_info[det_1_key]['At'] = {} #P is for peak in spectrum, and are ordered from low to high in retentiontime
fit_info[det_1_key]['At']['start'] = [22.5] #[21.4]
fit_info[det_1_key]['At']['end'] = [24.0] #[22.0] #[21.9]there's actually a second peak here that needs to be subtracted...
fit_info[det_1_key]['At']['name'] = 'Acetone '  + str(det_1_key)
fit_info[det_1_key]['At']['color'] = '#008080'
fit_info[det_1_key]['At']['mother_peak'] = []
electrons['At'] = 2


fit_info[det_1_key]['unknown1'] = {}
fit_info[det_1_key]['unknown1']['start'] = [30]
fit_info[det_1_key]['unknown1']['end'] =  [32.5]#[4]
fit_info[det_1_key]['unknown1']['name'] = 'unknown 1 ' + str(det_1_key)
fit_info[det_1_key]['unknown1']['color'] = 'b'
fit_info[det_1_key]['unknown1']['mother_peak'] = []
electrons['unknown1'] = 0 #not a product?!




fit_info[det_2_key] = {}
#208_4 - > normal wavelength
#balnk: 5.7, 13.44, 19.1
#PG: 16.2, AlAl: 20.9, At: 20.5, acrolein: 24.7 (only there?!), AcAc:

#
fit_info[det_2_key]['Acrolein'] = {}
fit_info[det_2_key]['Acrolein']['start'] = [23.9]
fit_info[det_2_key]['Acrolein']['end'] = [25.55] #25.8 for Pd samples
fit_info[det_2_key]['Acrolein']['name'] = 'acrolein ' + str(det_2_key)
fit_info[det_2_key]['Acrolein']['color'] = '#800080'
fit_info[det_2_key]['Acrolein']['mother_peak'] = []
electrons['Acrolein'] = 4
#
#
fit_info[det_2_key]['AcAc'] = {}
fit_info[det_2_key]['AcAc']['start'] = [16.7]
fit_info[det_2_key]['AcAc']['end'] = [18.5] #7.1 for samples with low acrolein (Au, Au rich), 8.5 for high acrolein
fit_info[det_2_key]['AcAc']['name'] = 'acrylic acid '+ str(det_2_key)
fit_info[det_2_key]['AcAc']['color'] = '#D70005'
fit_info[det_2_key]['AcAc']['mother_peak'] = []
electrons['AcAc'] = 6
#


fit_info[det_2_key]['unknown1'] = {}
fit_info[det_2_key]['unknown1']['start'] = [30]
fit_info[det_2_key]['unknown1']['end'] =  [32.5]#[4]
fit_info[det_2_key]['unknown1']['name'] = 'unknown 1 '+ str(det_2_key)
fit_info[det_2_key]['unknown1']['color'] = 'b'
fit_info[det_2_key]['unknown1']['mother_peak'] = []
electrons['unknown1'] = 0 #not a product?!

fit_info[det_2_key]['CH2CH2CH3'] = {}
fit_info[det_2_key]['CH2CH2CH3']['start'] = [32.5]
fit_info[det_2_key]['CH2CH2CH3']['end'] = [35]#[4]
fit_info[det_2_key]['CH2CH2CH3']['name'] = 'propene '+ str(det_2_key)
fit_info[det_2_key]['CH2CH2CH3']['color'] = 'grey'
fit_info[det_2_key]['CH2CH2CH3']['mother_peak'] = []
electrons['CH2CH2CH3'] = 0 #not a product?!

######

fit_info[det_3_key] = {}
#detector 3 is 280_10, main product of interest is acetone, but it doesnt really makes sense because also here overlap
#with allyl alcohol is too big
#blank: 2.6, 5.7
#500uM AcAc: 17.7, 20.6 (acrylic acid + ?)
#PG: 16.2,  acetone: 21.4, allyl alcohol: 20.6
#32: in 100muM Ac+AcAc STD!
#Ac+acrylonitrile STD: acylonitrile (?) at 14.4, 16.3, 31.66




# fit_info[det_3_key]['acetone'] = {} #P is for peak in spectrum, and are ordered from low to high in retentiontime
# fit_info[det_3_key]['acetone']['start'] = [3.6]
# fit_info[det_3_key]['acetone']['end'] = [4.5]
# fit_info[det_3_key]['acetone']['name'] = 'acetone'
# fit_info[det_3_key]['acetone']['color'] = '#008080'
# fit_info[det_3_key]['acetone']['mother_peak'] = []

######

fit_info[det_4_key] = {}
#detector 4 is RID, main product of interest is propylene glycol
#peaks that are also present in blank are at min 6.0 (negative), 8.5 (pos), 11.0 (pos), 18.0 (neg), 19.3(neg)
#acrylic acid at min 18, but positive (?!), acetone:21.75 , Allyl alc: 21.16

fit_info[det_4_key]['PG'] = {} #P is for peak in spectrum, and are ordered from low to high in retentiontime
fit_info[det_4_key]['PG']['start'] = [15.9]
fit_info[det_4_key]['PG']['end'] = [17.1]
fit_info[det_4_key]['PG']['name'] = 'propylene glycol '+ str(det_4_key)
fit_info[det_4_key]['PG']['color'] = '#006000'
fit_info[det_4_key]['PG']['mother_peak'] = []
electrons['PG'] = 2

fit_info[det_4_key]['CH2CH2CH3'] = {}
fit_info[det_4_key]['CH2CH2CH3']['start'] = [32.2]
fit_info[det_4_key]['CH2CH2CH3']['end'] =  [35]#[4]
fit_info[det_4_key]['CH2CH2CH3']['name'] = 'propene '+ str(det_4_key)
fit_info[det_4_key]['CH2CH2CH3']['color'] = 'grey'
fit_info[det_4_key]['CH2CH2CH3']['mother_peak'] = []
electrons['CH2CH2CH3'] = 0 #not a product?!