from Resources.HPLC_importing import HplcSequence

path = r"C:\Users\annawi\Desktop\Projects\Propene oxidation\Experiments\201905_PdAufoams\HPLC product analysis\POR_old_lamp_measurements"

sequence = HplcSequence(path)